import { formatCurrency } from "@/utils/format";
import { supabase } from "@/utils/supabase";
import { Download, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ExpensesFilter from "./ExpensesFilter";
import ExpensesFooter from "./ExpensesFooter";
import { ExpensesHeader } from "./ExpensesHeader";
import ExpensesRow from "./ExpensesRow";

const Expenses = () => {
  const [expenses, setExpenses] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const { data, error } = await supabase.from("expenses").select(`
      id, date, item_name, amount, actual_amount, note, categories(name), payment_methods(method_name)
      `);

      if (error) {
        console.error("Error fetching data:", error);
      } else {
        console.log("Data fetched!!", data);
        setExpenses(data);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="bg-white p-4 sm:p-6 lg:p-8 rounded-lg shadow-sm mt-6 mb-6">
      <ExpensesHeader />

      {/* 검색 및 필터 */}
      <ExpensesFilter />

      {/* 지출 목록 테이블 */}
      <ExpensesRow />

      {/* 페이지네이션 및 내보내기 */}
      <ExpensesFooter />
    </div>
  );
};

export default Expenses;
